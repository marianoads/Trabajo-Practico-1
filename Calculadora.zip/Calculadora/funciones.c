#include "funciones.h"
#include <stdio.h>
#include <stdlib.h>

void calculadora(int num1,int num2)
{
   sumar(num1,num2);
   restar(num1,num2);
   dividir(num1,num2);
   multiplicar(num1,num2);
   factorial(num1);

}

float sumar (int num1, int num2)
{
    return num1+num2;

}

float restar (int num1, int num2)
{
    return num1-num2;
}

float dividir (int num1, float num2)
{
    return num1/num2;
}

float multiplicar (int num1, int num2)
{

    return num1*num2;

}

float factorial (int num1)
{
    float resultado;
    float fact =1;
    for(int i=1; i<=num1; i++)
    {
        fact=fact*i;
    }
    resultado=fact;

    return resultado;
}

void mostrar (int num1, int num2)
{
    float resultadoSuma;
    float resultadoResta;
    float resultadoMultiplicacion;
    float resultadoDivision;
    float resultadoFactorial;

    resultadoSuma = sumar(num1,num2);
    printf("El resultado de la suma es :%.2f\n", resultadoSuma);

    resultadoResta = restar(num1,num2);
    printf("El resultado de la resta es :%.2f\n", resultadoResta);

    resultadoMultiplicacion = multiplicar(num1,num2);
    printf("El resultado de la multiplicacion es :%.2f\n", resultadoMultiplicacion);

    if(num1==0 || num2==0)
    {
        printf("No se puede dividir por 0\n");
    }
    else
    {
        resultadoDivision = dividir(num1, num2);
        printf("El resultado de la division es :%.2f\n", resultadoDivision);
    }


    resultadoFactorial = factorial(num1);
    printf("El resultado del factorial es :%.2f\n", resultadoFactorial);
}

