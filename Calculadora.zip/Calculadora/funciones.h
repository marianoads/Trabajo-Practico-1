#include <stdio.h>
#include <stdlib.h>
/** \brief  Recibe como parametro los 2 numeros a calcular
 *
 * \param  Hace calculos matematicos: suma, resta, division, multiplicacion y factorial
 * \param
 * \return no retorna nada
 *
 */
void calculadora(int num1,int num2);

/** \brief Recibe como parametro los 2 numeros a calcular, los suma y retorna el resultado
 *
 * \param Suma los dos numeros recibidos
 * \param
 * \return el resultado
 *
 */
float sumar (int num1, int num2);

/** \brief Recibe como parametro los 2 numeros a calcular, los resta y retorna el resultado
 *
 * \param Resta el numero1 por el numero2
 * \param
 * \return el resultado
 *
 */
float restar (int num1, int num2);

/** \brief Recibe como parametro los 2 numeros a calcular, los divide y retorna el resultado
 *
 * \param Divide el numero1 por el numero2
 * \param
 * \return el resultado
 *
 */
float dividir (int num1, float num2);

/** \brief Recibe como parametro los 2 numeros a calcular, los multiplica y retorna el resultado
 *
 * \param Multiplioca el numero1 por el numero2
 * \param
 * \return el resultado
 *
 */
float multiplicar (int num1, int num2);

/** \brief Recibe como parametro el numero a calcular y retorna el resultado
 *
 * \param Calcula el factorial del numero recibido
 * \param
 * \return el resultado
 *
 */
float factorial (int num1);

/** \brief Recibe como parametro los 2 numeros, hace el calculo y los muestra por consola
 *
 * \param Muestra el resultado de todos los calculos matematicos
 * \param
 * \return el resultado
 *
 */
void mostrar (int num1, int num2);
