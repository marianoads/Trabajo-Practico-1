#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"

int main()
{
    int num1;
    int num2;
    int opcion;
    char seguir = 's';
    int flagA=0;
    int flagB=0;

    while(seguir == 's')
    {
        printf("/////////////// CALCULADORA ///////////////");
        if(flagA==0)
        {
            printf("\n\n1-Ingrese primer operando : (A=x)\n");
        }
        else
        {
            printf("\n\n1-Ingrese primer operando : (A=%d)\n", num1);
        }
        if(flagB==0)
        {
            printf("2-Ingrese primer operando : (B=x)\n");
        }
        else
        {
            printf("2-Ingrese primer operando : (B=%d)\n", num2);
        }

        printf("3-Calcular todas las operaciones\n4-Mostrar todas las operaciones\n5-Salir\n\nIngrese opcion:");
        scanf("%d",&opcion);

        switch(opcion)
        {
        case 1:
            printf("Ingresar primer operando :");
            scanf("%d", &num1);
            flagA=1;
            break;
        case 2:
            printf("Ingresar segundo operando :");
            scanf("%d", &num2);
            flagB=1;
            break;
        case 3:
            calculadora(num1,num2);
            printf("Calculos hechos exitosamente!!");
            break;
        case 4:
            mostrar(num1,num2);
            system("pause");
            break;
        case 5:
            seguir = 'n';
            break;
        default:
            printf("Ingrese una opcion correcta 1-5\n\n");
            break;

        }
        system("cls");

    }


    return 0;
}
